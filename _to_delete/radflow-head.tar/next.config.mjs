/** @type {import('next').NextConfig} */
const nextConfig = {
  // Lint не повинен блокувати збірку/деплой.
  eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;
