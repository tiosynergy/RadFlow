"use client";

/* ===== RadFlow — Режим роботи (графік на дату) =====
   Портовано з queue-app.jsx (ScheduleEditModal). Закрити всю клініку (свято/вихідний)
   або змінити графік окремих кабінетів. Зберігається у schedule_overrides. */

import { useState } from "react";
import { DEF_START, DEF_END, roomScheduleFor, normalizeBreaks, type DayOverride, type Break } from "@/lib/schedule";
import { useModalA11y } from "@/lib/useModalA11y";
import { modalityLabel, modalityKind, modalityIcon } from "@/lib/studies";

const LABELS = ["Державне свято", "Вихідний день", "Санітарний день", "Технічне обслуговування"];

type RoomOpt = { id: string; modality: string; name: string; apparatus_model?: string | null; schedule?: unknown };
type RoomMode = { mode: "open" | "custom" | "closed"; start: string; end: string; breaks: Break[] };
type OverrideBuild = {
  all_closed: boolean;
  label?: string;
  rooms: Record<string, { closed?: boolean; start?: string; end?: string; breaks?: Break[] }>;
};
type AffectedEntry = { status: string; room_id: string | null };

interface ScheduleEditModalProps {
  date: Date;
  rooms?: RoomOpt[];
  existing?: DayOverride | null;
  entries?: AffectedEntry[];
  onClose: () => void;
  onSave: (ov: OverrideBuild) => void;
  onReset: () => void;
}

/* Нормалізація часу до канону "HH:MM" (сервер тепер вимагає саме його — zTime, M-1).
   `<input type="time">` у деяких браузерах віддає "9:05" або "", а в rooms.schedule
   можуть лежати легасі-значення. Раніше таке мовчки їхало в JSONB, і сітка слотів
   на цю дату просто зникала. Повертає "" для нерозбірного значення. */
function normHM(v: string | null | undefined): string {
  const m = String(v ?? "").trim().match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return "";
  const h = Number(m[1]), mi = Number(m[2]);
  if (h > 23 || mi > 59) return "";
  return String(h).padStart(2, "0") + ":" + m[2];
}
const hoursOk = (s: string, e: string) => !!s && !!e && s < e;
function fmtShort(d: Date) {
  const MON = ["січня", "лютого", "березня", "квітня", "травня", "червня", "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"];
  return d.getDate() + " " + MON[d.getMonth()];
}

export default function ScheduleEditModal({ date, rooms, existing, entries, onClose, onSave, onReset }: ScheduleEditModalProps) {
  const dialogRef = useModalA11y<HTMLDivElement>(onClose);
  const [allClosed, setAllClosed] = useState(!!(existing && existing.all_closed));
  const [label, setLabel] = useState((existing && existing.label) || "");
  const [roomState, setRoomState] = useState<Record<string, RoomMode>>(() => {
    const m: Record<string, RoomMode> = {};
    (rooms || []).forEach((r) => {
      const eff = roomScheduleFor(date, r.id, existing, r.schedule); // база кабінету + override на дату
      const ro = existing && existing.rooms ? existing.rooms[r.id] : null;
      const brk = normalizeBreaks(ro);
      /* «Типово» = БАЗОВИЙ графік кабінету (rooms.schedule), а не хардкод 08–18.
         Режим визначаємо за наявністю override на цю дату, а не за тим, чи
         збігаються години з дефолтом: інакше кабінет із графіком 09:00–15:00
         щоразу відкривався б як «Інші години» і зберігав зайвий override. */
      const mode: RoomMode["mode"] = ro
        ? (ro.closed ? "closed" : "custom")
        : (eff.closed ? "closed" : "open"); // база кабінету може закривати цей день
      m[r.id] = { mode, start: eff.start || DEF_START, end: eff.end || DEF_END, breaks: brk };
    });
    return m;
  });
  function setRoom(k: string, patch: Partial<RoomMode>) { setRoomState((s) => ({ ...s, [k]: { ...s[k], ...patch } })); }
  function addBreak(k: string) { setRoomState((s) => ({ ...s, [k]: { ...s[k], breaks: [...s[k].breaks, { start: "13:00", end: "14:00" }] } })); }
  function setBreak(k: string, i: number, patch: Partial<Break>) { setRoomState((s) => { const bs = s[k].breaks.slice(); bs[i] = { ...bs[i], ...patch }; return { ...s, [k]: { ...s[k], breaks: bs } }; }); }
  function delBreak(k: string, i: number) { setRoomState((s) => ({ ...s, [k]: { ...s[k], breaks: s[k].breaks.filter((_, j) => j !== i) } })); }

  /* «Типово» для кабінету = його БАЗОВИЙ графік (rooms.schedule), а не хардкод
     «Пн–Сб 08–18». Раніше тут стояв defaultClosed(date) (лише неділя), тому:
       • кабінет, закритий у суботу власним графіком, показувався як «Працює»;
       • вибір «Працює» на такий день нічого не писав → кабінет мовчки лишався
         закритим, а вибір «Працює» на неділю писав зайвий override. */
  const baseClosedOf = (r: RoomOpt) => roomScheduleFor(date, r.id, null, r.schedule).closed;

  function buildOv(): OverrideBuild {
    if (allClosed) return { all_closed: true, label: label.trim() || "Неробочий день", rooms: {} };
    const ro: OverrideBuild["rooms"] = {};
    (rooms || []).forEach((r) => {
      const st = roomState[r.id];
      // Години нормалізуємо до "HH:MM"; невалідні перерви відкидаємо (як і раніше).
      const start = normHM(st.start), end = normHM(st.end);
      const vb = st.breaks
        .map((b) => ({ start: normHM(b.start), end: normHM(b.end) }))
        .filter((b) => hoursOk(b.start, b.end));
      const baseClosed = baseClosedOf(r);
      if (st.mode === "closed") { if (!baseClosed) ro[r.id] = { closed: true }; }
      else if (st.mode === "custom") { ro[r.id] = { start, end, ...(vb.length ? { breaks: vb } : {}) }; }
      else { if (baseClosed) ro[r.id] = { start, end }; } // «Працює» всупереч базовому графіку
    });
    const o: OverrideBuild = { all_closed: false, rooms: ro };
    if (label.trim()) o.label = label.trim();
    return o;
  }

  /* Кабінети з битими годинами (порожнє поле, «18:00–08:00»). Раніше такі значення
     мовчки зберігались, і сітка слотів на цю дату зникала; тепер їх ще й відхилить
     сервер (zTime + start < end), тож блокуємо «Зберегти» і кажемо, ЩО не так. */
  const badRooms = allClosed ? [] : (rooms || []).filter((r) => {
    const st = roomState[r.id];
    if (!st || st.mode === "closed") return false;
    if (st.mode === "open" && !baseClosedOf(r)) return false;   // override не пишеться
    return !hoursOk(normHM(st.start), normHM(st.end));
  });

  // Записи, яких торкнеться закриття/зміна (scheduled/waiting у кабінетах, що закриваються).
  const previewOv = buildOv();
  const affected = (entries || []).filter((e) => {
    if (e.status !== "scheduled" && e.status !== "waiting") return false;
    if (previewOv.all_closed) return true;
    const ro = e.room_id && previewOv.rooms ? previewOv.rooms[e.room_id] : null;
    if (ro && ro.closed) return true;
    return false;
  });

  return (
    <div className="overlay">
      <div className="dialog fade-in" style={{ maxWidth: 560 }} ref={dialogRef} role="dialog" aria-modal="true" aria-label="Графік роботи на день">
        <div className="dlg-head">
          <div className="dlg-title"><span className="tic">🗓</span>Режим роботи · {fmtShort(date)}</div>
          <button className="icon-btn" onClick={onClose}>✕</button>
        </div>
        <div className="dlg-body">
          <div className="ctx-hint blue">Графік на <b>{fmtShort(date)}</b>. Закрийте всю клініку на свято/вихідний або змініть години окремих кабінетів. Зміни одразу відображаються в календарі та черзі.</div>

          <label className="sch-allclosed">
            <input type="checkbox" checked={allClosed} onChange={(e) => setAllClosed(e.target.checked)} />
            <span><b>Неробочий день</b> — вся клініка зачинена</span>
          </label>

          <label className="fld">
            <span className="fld-lab">Причина / підпис{allClosed ? "" : " (необов'язково)"}</span>
            <input className="inp" placeholder="напр. Державне свято" value={label} onChange={(e) => setLabel(e.target.value)} />
            <div className="sch-chips">
              {LABELS.map((l) => <button key={l} type="button" className={"sch-chip" + (label === l ? " on" : "")} onClick={() => setLabel(label === l ? "" : l)}>{l}</button>)}
            </div>
          </label>

          {!allClosed && (
            <div className="sch-rooms">
              <div className="sch-rooms-lab">Кабінети та обладнання</div>
              {(rooms || []).map((r) => {
                const st = roomState[r.id];
                return (
                  <div className="sch-room" key={r.id}>
                    <div className="sch-room-info">
                      <span className={"sch-room-ic " + modalityKind(r.modality)}>{modalityIcon(r.modality)}</span>
                      <div className="sch-room-txt">
                        <span className="sch-room-name">{r.name}</span>
                        <span className="sch-room-model">{modalityLabel(r.modality)}{r.apparatus_model ? " · " + r.apparatus_model : ""}</span>
                      </div>
                    </div>
                    <div className="sch-room-ctl">
                      <div className="bk-seg bk-seg-sm">
                        <button className={"bk-seg-btn" + (st.mode === "open" ? " active" : "")} onClick={() => setRoom(r.id, { mode: "open" })}>Працює</button>
                        <button className={"bk-seg-btn" + (st.mode === "custom" ? " active" : "")} onClick={() => setRoom(r.id, { mode: "custom" })}>Інші години</button>
                        <button className={"bk-seg-btn" + (st.mode === "closed" ? " active" : "")} onClick={() => setRoom(r.id, { mode: "closed" })}>Зачинено</button>
                      </div>
                      {st.mode === "custom" && (
                        <div className="sch-hours">
                          <input className="inp tabular" type="time" value={st.start} onChange={(e) => setRoom(r.id, { start: e.target.value })} />
                          <span className="sch-dash">–</span>
                          <input className="inp tabular" type="time" value={st.end} onChange={(e) => setRoom(r.id, { end: e.target.value })} />
                        </div>
                      )}
                      {st.mode === "custom" && (
                        <div className="sch-breaks">
                          <div className="sch-breaks-lab">Перерви (обід тощо)</div>
                          {st.breaks.map((b, i) => {
                            const bad = !(b.start && b.end && b.start < b.end);
                            return (
                              <div className="sch-break-row" key={i}>
                                <input className={"inp tabular" + (bad ? " invalid" : "")} type="time" value={b.start} onChange={(e) => setBreak(r.id, i, { start: e.target.value })} />
                                <span className="sch-dash">–</span>
                                <input className={"inp tabular" + (bad ? " invalid" : "")} type="time" value={b.end} onChange={(e) => setBreak(r.id, i, { end: e.target.value })} />
                                <button type="button" className="icon-btn sch-break-del" onClick={() => delBreak(r.id, i)} title="Прибрати перерву">✕</button>
                              </div>
                            );
                          })}
                          <button type="button" className="sch-break-add" onClick={() => addBreak(r.id)}>+ Додати перерву</button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {badRooms.length > 0 && (
            <div className="ctx-hint red sch-affected">
              <div className="sch-aff-head">⚠ Некоректні години: {badRooms.map((r) => r.name).join(", ")}</div>
              <div className="sch-aff-sub">Вкажіть початок і кінець у форматі ГГ:ХХ, кінець — пізніше за початок.</div>
            </div>
          )}

          {affected.length > 0 && (
            <div className="ctx-hint red sch-affected">
              <div className="sch-aff-head">⚠ На цю дату вже заплановано {affected.length} {affected.length === 1 ? "запис" : "записів"} у кабінетах, що закриваються.</div>
              <div className="sch-aff-sub">Після збереження їх буде позначено бейджем «🔧 Перезапис» і додано до панелі переносу.</div>
            </div>
          )}
        </div>
        <div className="dlg-foot sch-foot">
          {existing
            ? <button className="btn btn-ghost sch-reset" onClick={onReset} title="Прибрати ручні зміни — повернути типовий графік">↺ Скинути до типового</button>
            : <span className="sch-foot-sp" style={{ marginRight: "auto" }} />}
          <div className="sch-foot-r" style={{ display: "flex", gap: 8, marginLeft: "auto" }}>
            <button className="btn btn-ghost" onClick={onClose}>Скасувати</button>
            <button
              className="btn btn-primary"
              disabled={badRooms.length > 0}
              title={badRooms.length ? "Перевірте години: " + badRooms.map((r) => r.name).join(", ") + " — кінець має бути пізніше за початок" : undefined}
              onClick={() => onSave(buildOv())}
            >✓ Зберегти графік</button>
          </div>
        </div>
      </div>
    </div>
  );
}
