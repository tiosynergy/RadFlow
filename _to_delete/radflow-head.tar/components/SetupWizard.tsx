"use client";

/* ===== RadFlow — Setup Wizard (Майстер налаштування) =====
   Портовано з прототипу wizard-app.jsx + wizard-steps.jsx.
   Дані префілляться з Supabase і зберігаються при «Запустити кабінет». */

import { useState, useEffect, useRef, type Dispatch, type SetStateAction } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { Json, TablesInsert, Tables } from "@/supabase/types";
import CitySelect from "@/components/CitySelect";
import ServicesEditor from "@/components/ServicesEditor";
import StaffManager from "@/components/StaffManager";
import ReferrersManager from "@/components/ReferrersManager";
import CeoManager from "@/components/CeoManager";
import QueuePolicySettings, { type QueuePolicyInitial } from "@/components/QueuePolicySettings";
import ConfirmDialog from "@/components/ConfirmDialog";
import { formatPhoneUA, isValidPhoneUA } from "@/lib/phone";
import "@/styles/prototype/radflow.css";
import "@/styles/prototype/radflow-screens.css";
import "@/styles/prototype/radflow-wizard.css";
import type { Break } from "@/lib/schedule";
import { MODALITIES, modalityCode } from "@/lib/studies";

/* ===== Таймзона центру (IANA) =====
   Від неї залежать «Запізнення», «Уточнити», гарди виклику в кабінет і заборона
   запису в минуле (канон wall-as-UTC, міграції 0035/0059). Тому це ЯВНЕ поле, а
   не мовчазний авто-детект браузера при кожному збереженні. */
function browserTz(): string {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "Europe/Kyiv"; }
  catch { return "Europe/Kyiv"; }
}
/** Повний список зон (сучасні рушії) з фолбеком на короткий перелік. */
function tzList(): string[] {
  const withValues = Intl as unknown as { supportedValuesOf?: (k: string) => string[] };
  try {
    const all = withValues.supportedValuesOf?.("timeZone");
    if (all && all.length) return all;
  } catch { /* старий рушій — фолбек нижче */ }
  return ["Europe/Kyiv", "Europe/Warsaw", "Europe/Berlin", "Europe/Prague", "Europe/Vilnius",
    "Europe/Riga", "Europe/Bucharest", "Europe/Chisinau", "Europe/London", "Europe/Lisbon",
    "Europe/Madrid", "Europe/Rome", "Europe/Istanbul", "Asia/Tbilisi", "UTC"];
}
/** «Europe/Kyiv · 15:42» — щоб адмін одразу бачив, чи час центру збігається з реальним. */
function tzNow(tz: string): string {
  try { return new Intl.DateTimeFormat("uk-UA", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date()); }
  catch { return "—"; }
}

type Toast = { id: number; msg: string; type: string; out?: boolean };
type DayHours = { start: string; end: string; breaks: Break[] };
type EquipItem = {
  id: number | string;
  type: string; desc: string; room: string;
  days: number[];
  start: string; end: string; breaks: Break[];
  perDay: boolean; dayHours: DayHours[];
  roomId?: string;
};
type WizardData = {
  clinic: string; city: string; address: string; phones: string[]; emails: string[];
  timezone: string;
  adminName: string; adminEmail: string; aPhones: string[]; aEmails: string[]; equip: EquipItem[];
};
type WizardInitial = Partial<{
  clinic: string; city: string; address: string; phones: string[]; emails: string[];
  timezone: string;
  adminName: string; adminEmail: string; adminPhone: string; equip: EquipItem[];
}>;

/* ---------- Toasts ---------- */
function Toasts({ toasts }: { toasts: Toast[] }) {
  const icons: Record<string, string> = { success: "✓", error: "✕", info: "ℹ", warning: "⚠" };
  return (
    <div className="toast-wrap">
      {toasts.map((t) => (
        <div className={"toast " + t.type + (t.out ? " out" : "")} key={t.id}>
          <span className="ti">{icons[t.type]}</span>
          <span className="tmsg">{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function useToasts(): [Toast[], (msg: string, type?: string) => void] {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const seq = useRef(0);
  function push(msg: string, type = "success") {
    const id = ++seq.current;
    setToasts((ts) => [...ts, { id, msg, type }]);
    setTimeout(() => setToasts((ts) => ts.map((t) => (t.id === id ? { ...t, out: true } : t))), 3400);
    setTimeout(() => setToasts((ts) => ts.filter((t) => t.id !== id)), 3700);
  }
  return [toasts, push];
}

const Req = () => <span className="req" title="Обов'язкове поле">*</span>;

/* Список телефонів / email-ів */
function ContactList({ label, items, setItems, type, ph, required }: {
  label: string;
  items: string[];
  setItems: Dispatch<SetStateAction<string[]>>;
  type?: string;
  ph?: string;
  required?: boolean;
}) {
  const isPhone = type !== "email";
  const noun = isPhone ? "телефон" : "email";
  const upd = (i: number, v: string) => setItems((a) => a.map((x, j) => (j === i ? v : x)));
  const add = () => setItems((a) => [...a, ""]);
  const del = (i: number) => setItems((a) => (a.length > 1 ? a.filter((_, j) => j !== i) : [""]));
  const empty = required && items.every((x) => x.trim() === "");
  return (
    <div className="fld">
      <span className="fld-lab">{label}{required && <Req />}</span>
      {items.map((v, i) => {
        const badPhone = isPhone && v.trim() !== "" && !isValidPhoneUA(v);
        return (
        <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <input className={"inp" + ((empty && i === 0) || badPhone ? " invalid" : "")} type={isPhone ? "tel" : "email"} inputMode={isPhone ? "tel" : undefined} placeholder={ph} value={v}
            onChange={(e) => upd(i, isPhone ? formatPhoneUA(e.target.value) : e.target.value)} />
          <button className="mini-icon" type="button" title={"Видалити " + noun} onClick={() => del(i)}>✕</button>
        </div>
        );
      })}
      <button className="btn btn-secondary btn-sm add-btn" type="button" onClick={add}>＋ Додати {noun}</button>
    </div>
  );
}

const EQ_DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];
const DEF_START_T = "08:00", DEF_END_T = "18:00";
const mkDay = (): DayHours => ({ start: DEF_START_T, end: DEF_END_T, breaks: [] });
const tbMin = (t: string) => { const [h, m] = (t || "").split(":").map(Number); return (h || 0) * 60 + (m || 0); };
const minToT = (n: number) => String(Math.floor(n / 60)).padStart(2, "0") + ":" + String(n % 60).padStart(2, "0");
/* Розумний дефолт нової перерви: перша — типовий обід 13:00–14:00 (якщо
   вписується), наступні — одразу після попередньої, у межах графіка, БЕЗ
   перетину. Так додавання перерв «просто працює», не впираючись у помилки. */
function defaultBreak(existing: Break[], dayStart: string, dayEnd: string): Break {
  const lo = tbMin(dayStart || DEF_START_T), hi = tbMin(dayEnd || DEF_END_T);
  if (existing.length === 0 && tbMin("13:00") >= lo && tbMin("14:00") <= hi) return { start: "13:00", end: "14:00" };
  const lastEnd = existing.length ? Math.max(...existing.map((b) => tbMin(b.end) || lo)) : lo;
  let s = Math.max(lastEnd, lo);
  let e = Math.min(s + 60, hi);
  if (e <= s) { s = lo; e = Math.min(lo + 60, hi); } // графік заповнений — валідний інтервал, користувач підправить
  return { start: minToT(s), end: minToT(e) };
}
function mkSched(): Omit<EquipItem, "id" | "type" | "desc" | "room" | "roomId"> {
  return { days: [1, 1, 1, 1, 1, 0, 0], start: DEF_START_T, end: DEF_END_T, breaks: [], perDay: false, dayHours: Array.from({ length: 7 }, () => mkDay()) };
}

/* Валідація однієї перерви в контексті свого списку та годин дня.
   Час у форматі "HH:MM" коректно порівнюється лексикографічно. */
function breakRowError(list: Break[], bi: number, dayStart: string, dayEnd: string): string | null {
  const b = list[bi];
  if (!b.start || !b.end) return "Вкажіть початок і кінець перерви";
  if (b.end <= b.start) return "Кінець перерви раніший за початок";
  if (dayStart && b.start < dayStart) return "Перерва до відкриття кабінету";
  if (dayEnd && b.end > dayEnd) return "Перерва після закриття кабінету";
  for (let j = 0; j < list.length; j++) {
    if (j === bi) continue;
    const o = list[j];
    if (o.start && o.end && o.end > o.start && b.start < o.end && o.start < b.end) return "Перетин з іншою перервою";
  }
  return null;
}
/* Валідація годин самого дня (не перерви). Порожнє поле або кінець ≤ початок
   раніше зберігались мовчки — і сітка слотів просто зникала (roomScheduleFor
   не дає жодного слота при start ≥ end). Тепер це помилка, що блокує «Зберегти». */
function dayHoursError(start: string, end: string): string | null {
  if (!start || !end) return "Вкажіть години роботи";
  if (end <= start) return "Кінець раніший за початок";
  return null;
}
/** Чи всі перерви всіх кабінетів коректні (для гейтингу «Зберегти»). */
function equipBreaksValid(equip: EquipItem[]): boolean {
  return equip.every((e) =>
    e.perDay
      ? e.dayHours.every((dh, di) => !e.days[di] || dh.breaks.every((_, bi) => breakRowError(dh.breaks, bi, dh.start, dh.end) === null))
      : e.breaks.every((_, bi) => breakRowError(e.breaks, bi, e.start, e.end) === null)
  );
}
/** Чи коректні години роботи всіх кабінетів (для гейтингу «Зберегти»).
    perDay: перевіряємо кожен УВІМКНЕНИЙ день; інакше — єдині години кабінету. */
function equipHoursValid(equip: EquipItem[]): boolean {
  return equip.every((e) =>
    e.perDay
      ? e.dayHours.every((dh, di) => !e.days[di] || dayHoursError(dh.start, dh.end) === null)
      : dayHoursError(e.start, e.end) === null
  );
}

/* Пункти бічної навігації майстра (кружки без нумерації).
   Профіль / Адміністратор / Обладнання / Прайс — секції цього екрана (anchor);
   Радіологи / Направники / Керівники — окремі сторінки керування (href). */
const WIZ_NAV: { label: string; desc: string; anchor?: string; href?: string }[] = [
  { label: "Профіль клініки", desc: "Назва та контакти центру", anchor: "sec-clinic" },
  { label: "Адміністратор", desc: "Обліковий запис адміна", anchor: "sec-admin" },
  { label: "Обладнання та кабінети", desc: "Апарати та розклад", anchor: "sec-equip" },
  { label: "Послуги та прайс", desc: "Каталог послуг і цін центру", anchor: "sec-price" },
  { label: "Управління чергою", desc: "Політика при затримці", anchor: "sec-queue" },
  { label: "Персонал і доступи", desc: "Радіологи та реєстратори", anchor: "sec-staff" },
  { label: "Лікарі-направники", desc: "Направники центру", anchor: "sec-referrers" },
  { label: "Керівники (CEO)", desc: "Аналітичний доступ", anchor: "sec-ceo" },
];
// Секції, що належать майстру первинного налаштування (з кнопкою «Запустити кабінет»).
const FORM_SECTIONS = ["sec-clinic", "sec-admin", "sec-equip", "sec-price"];

/* ---------- Крок 1: Профіль клініки ---------- */
function StepRegister({ report, onData, initial, active, clinicId, services, rooms, roomOverrides }: { report: (k: number, ok: boolean) => void; onData: (d: WizardData) => void; initial: WizardInitial; active: string; clinicId: string; services: ServiceRow[]; rooms: SetupRoom[]; roomOverrides: SroRow[] }) {
  const [clinic, setClinic] = useState(initial.clinic || "");
  const [city, setCity] = useState(initial.city || "");
  const [address, setAddress] = useState(initial.address || "");
  const [phones, setPhones] = useState<string[]>(initial.phones && initial.phones.length ? initial.phones : [""]);
  const [emails, setEmails] = useState<string[]>(initial.emails && initial.emails.length ? initial.emails : [""]);
  /* Таймзона ЦЕНТРУ (IANA). Раніше її мовчки перезаписувала зона БРАУЗЕРА при
     кожному «Зберегти» — адмін з іншої країни (або з увімкненим VPN) ламав час
     усієї клініки: від нього залежать «Запізнення», «Уточнити», гарди виклику й
     заборона запису в минуле. Тепер це явне поле; авто-детект — лише як
     початкове значення для НОВОЇ клініки. */
  const [timezone, setTimezone] = useState(initial.timezone || browserTz());

  const [adminName, setAdminName] = useState(initial.adminName || "");
  const [adminEmail, setAdminEmail] = useState(initial.adminEmail || "");
  const [aPhones, setAPhones] = useState<string[]>([initial.adminPhone || ""]);
  const [aEmails, setAEmails] = useState<string[]>([""]);

  const [equip, setEquip] = useState<EquipItem[]>(
    initial.equip && initial.equip.length
      ? initial.equip
      : [{ id: 1, type: "МРТ", desc: "", room: "Кабінет №1", ...mkSched() }]
  );

  useEffect(() => {
    const adminPhoneOk = aPhones.some((p) => p.trim() !== "");
    const ok = clinic.trim() !== "" && city.trim() !== "" && adminName.trim() !== "" && adminPhoneOk && equip.length > 0 && equipHoursValid(equip) && equipBreaksValid(equip);
    report(1, !!ok);
    onData({ clinic, city, address, phones, emails, timezone, adminName, adminEmail, aPhones, aEmails, equip });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clinic, city, address, phones, emails, timezone, adminName, adminEmail, aPhones, aEmails, equip]);

  function setEq(i: number, k: string, v: string | boolean) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, [k]: v } : x))); }
  function toggleEqDay(i: number, d: number) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, days: x.days.map((v, k) => (k === d ? (v ? 0 : 1) : v)) } : x))); }
  function setEqDay(i: number, di: number, k: string, v: string | boolean) {
    setEquip((a) => a.map((x, j) => (j === i ? { ...x, dayHours: x.dayHours.map((dh, k2) => (k2 === di ? { ...dh, [k]: v } : dh)) } : x)));
  }
  function toggleEqPerDay(i: number, on: boolean) {
    setEquip((a) => a.map((x, j) => {
      if (j !== i) return x;
      if (!on) return { ...x, perDay: false };
      // Засіваємо кожен день годинами й перервами загального графіка (свіжі копії).
      return { ...x, perDay: true, dayHours: Array.from({ length: 7 }, () => ({ start: x.start, end: x.end, breaks: x.breaks.map((b) => ({ ...b })) })) };
    }));
  }
  // Перерви загального графіка (весь тиждень).
  function addEqBreak(i: number) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, breaks: [...x.breaks, defaultBreak(x.breaks, x.start, x.end)] } : x))); }
  function setEqBreak(i: number, bi: number, k: "start" | "end", v: string) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, breaks: x.breaks.map((b, k2) => (k2 === bi ? { ...b, [k]: v } : b)) } : x))); }
  function delEqBreak(i: number, bi: number) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, breaks: x.breaks.filter((_, k2) => k2 !== bi) } : x))); }
  // Перерви окремого дня (режим «свій час для кожного дня»).
  function addEqDayBreak(i: number, di: number) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, dayHours: x.dayHours.map((dh, k2) => (k2 === di ? { ...dh, breaks: [...dh.breaks, defaultBreak(dh.breaks, dh.start, dh.end)] } : dh)) } : x))); }
  function setEqDayBreak(i: number, di: number, bi: number, k: "start" | "end", v: string) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, dayHours: x.dayHours.map((dh, k2) => (k2 === di ? { ...dh, breaks: dh.breaks.map((b, k3) => (k3 === bi ? { ...b, [k]: v } : b)) } : dh)) } : x))); }
  function delEqDayBreak(i: number, di: number, bi: number) { setEquip((a) => a.map((x, j) => (j === i ? { ...x, dayHours: x.dayHours.map((dh, k2) => (k2 === di ? { ...dh, breaks: dh.breaks.filter((_, k3) => k3 !== bi) } : dh)) } : x))); }
  function addEq() { setEquip((a) => [...a, { id: Date.now(), type: "МРТ", desc: "", room: "", ...mkSched() }]); }
  function delEq(i: number) { setEquip((a) => a.filter((_, j) => j !== i)); }

  /* Видалення кабінету — через ПІДТВЕРДЖЕННЯ (раніше ✕ зносив картку миттєво, без
     попередження й без шансу відмінити). Для НАЯВНОГО кабінету (є roomId) спершу
     перевіряємо активні записи в черзі: якщо є — видалення блокуємо (інакше save
     усе одно відхилить, але вже після втрати картки, і незрозуміло чому). Перевірка
     best-effort: якщо не вдалось — м'яке підтвердження (save лишається запобіжником). */
  const [delAsk, setDelAsk] = useState<{ i: number; name: string; count: number | null; checking: boolean } | null>(null);
  async function askDelEq(i: number) {
    const e = equip[i];
    const name = (e.room || e.type || "Кабінет").trim();
    if (!e.roomId) { setDelAsk({ i, name, count: 0, checking: false }); return; }   // новий кабінет — записів бути не може
    setDelAsk({ i, name, count: null, checking: true });
    try {
      const supabase = createClient();
      const { count, error } = await supabase
        .from("queue_entries")
        .select("id", { count: "exact", head: true })
        .eq("room_id", e.roomId)
        .in("status", ["scheduled", "waiting", "in_progress", "needs_reschedule"]);
      if (error) throw error;
      setDelAsk((cur) => (cur && cur.i === i ? { ...cur, count: count ?? 0, checking: false } : cur));
    } catch {
      setDelAsk((cur) => (cur && cur.i === i ? { ...cur, count: null, checking: false } : cur)); // не змогли перевірити
    }
  }

  return (
    <div className="fade-in">
      {active === "sec-clinic" && (<>
      <h1 className="wiz-h">Профіль клініки</h1>
      <p className="wiz-hsub">Базові дані центру.</p>

      <div className="info-banner" style={{ marginTop: 16 }}>
        <span className="ib-ic" style={{ color: "var(--green)" }}>✓</span>
        <span className="ib-txt"><b>Email підтверджено.</b> Обліковий запис активовано.</span>
      </div>

      <div className="sec-label" style={{ marginTop: 16 }}>Медичний центр</div>
      <div className="form-card reg-card">
        <div className="fld-row">
          <label className="fld"><span className="fld-lab">Назва клініки <Req /></span>
            <input className={"inp" + (clinic.trim() ? "" : " invalid")} value={clinic} onChange={(e) => setClinic(e.target.value)} /></label>
          <span className="fld-spacer" />
        </div>
        <div className="fld-row">
          <label className="fld"><span className="fld-lab">Місто <Req /></span>
            <CitySelect value={city} onChange={setCity} required /></label>
          <label className="fld" style={{ flex: 2 }}><span className="fld-lab">Адреса</span>
            <input className="inp" placeholder="вул., будинок, поверх, індекс" value={address} onChange={(e) => setAddress(e.target.value)} /></label>
        </div>
        <div className="fld-row">
          <label className="fld"><span className="fld-lab">Часовий пояс центру <Req /></span>
            <select className="inp" value={timezone} onChange={(e) => setTimezone(e.target.value)}>
              {(tzList().includes(timezone) ? tzList() : [timezone, ...tzList()]).map((z) => (
                <option key={z} value={z}>{z}</option>
              ))}
            </select>
            <span className="fld-hint">Зараз у центрі: {tzNow(timezone)}. За цим часом рахуються «Запізнення», «Уточнити» та заборона запису в минуле — не змінюйте, якщо ви в іншій країні за центр.</span>
          </label>
          <span className="fld-spacer" />
        </div>
        <div className="contacts-grid">
          <ContactList label="Телефони" items={phones} setItems={setPhones} ph="+38 0__ ___ __ __" />
          <ContactList label="Email-и" items={emails} setItems={setEmails} type="email" ph="name@clinic.ua" />
        </div>
      </div>

      </>)}

      {active === "sec-admin" && (<>
      <h1 className="wiz-h">Адміністратор</h1>
      <p className="wiz-hsub">Обліковий запис адміністратора центру.</p>
      <div className="form-card reg-card" style={{ marginTop: 16 }}>
        <div className="fld-row">
          <label className="fld">
            <span className="fld-lab">ПІБ адміністратора <Req /></span>
            <input className={"inp" + (adminName.trim() ? "" : " invalid")} placeholder="Прізвище Ім'я По батькові" value={adminName} onChange={(e) => setAdminName(e.target.value)} />
          </label>
          <label className="fld">
            <span className="fld-lab">Email для входу <Req /></span>
            <input className="inp" type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} readOnly />
            <span className="fld-hint">Логін · роль: Адміністратор</span>
          </label>
        </div>
        <div className="contacts-grid">
          <ContactList label="Телефони" items={aPhones} setItems={setAPhones} ph="+38 0__ ___ __ __" required />
          <ContactList label="Email-и" items={aEmails} setItems={setAEmails} type="email" ph="name@example.com" />
        </div>
      </div>

      </>)}

      {active === "sec-equip" && (<>
      <h1 className="wiz-h">Обладнання та кабінети <Req /></h1>
      <p className="wiz-hsub">Апарати центру та їхній графік роботи.</p>
      <div className="form-card" style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 16 }}>
        {equip.map((e, i) => (
          <div key={e.id} className="equip-block">
            <button className="mini-icon equip-block-del" type="button" title="Видалити обладнання" onClick={() => askDelEq(i)} disabled={equip.length <= 1}>✕</button>
            <div className="equip-info">
              <div className="equip-info-row">
                <select className="inp equip-type" value={e.type} onChange={(ev) => setEq(i, "type", ev.target.value)}>
                  {MODALITIES.map((m) => <option key={m.code} value={m.label}>{m.label}</option>)}
                </select>
                <input className="inp equip-room2" placeholder="Кабінет / №" value={e.room} onChange={(ev) => setEq(i, "room", ev.target.value)} />
              </div>
              <input className="inp" placeholder="Модель / опис обладнання" value={e.desc} onChange={(ev) => setEq(i, "desc", ev.target.value)} />
            </div>
            <div className="equip-sched">
              <span className="equip-sched-lab">Розклад роботи</span>
              <div className="eq-days">
                {EQ_DAYS.map((d, di) => (
                  <button key={d} type="button" className={"eq-day" + (e.days[di] ? " on" : "")} title={d} onClick={() => toggleEqDay(i, di)}>{d}</button>
                ))}
              </div>

              <label className="eq-perday-lab">
                <input type="checkbox" checked={e.perDay} onChange={(ev) => toggleEqPerDay(i, ev.target.checked)} />
                Свій час для кожного дня
              </label>

              {!e.perDay && (() => {
                const hErr = dayHoursError(e.start, e.end);
                return (
                <>
                  <div className="eq-hours">
                    <input className={"inp tabular eq-time" + (hErr ? " invalid" : "")} type="time" value={e.start} onChange={(ev) => setEq(i, "start", ev.target.value)} />
                    <span className="eq-dash">–</span>
                    <input className={"inp tabular eq-time" + (hErr ? " invalid" : "")} type="time" value={e.end} onChange={(ev) => setEq(i, "end", ev.target.value)} />
                  </div>
                  {hErr && <span className="eq-break-err">{hErr}</span>}
                  <div className="eq-breaks">
                    {e.breaks.map((b, bi) => {
                      const err = breakRowError(e.breaks, bi, e.start, e.end);
                      return (
                        <div className={"eq-break-row" + (err ? " has-err" : "")} key={bi}>
                          <span className="eq-break-tag">Перерва</span>
                          <div className="eq-hours">
                            <input className={"inp tabular eq-time" + (err ? " invalid" : "")} type="time" value={b.start} onChange={(ev) => setEqBreak(i, bi, "start", ev.target.value)} />
                            <span className="eq-dash">–</span>
                            <input className={"inp tabular eq-time" + (err ? " invalid" : "")} type="time" value={b.end} onChange={(ev) => setEqBreak(i, bi, "end", ev.target.value)} />
                          </div>
                          <button className="mini-icon" type="button" title="Прибрати перерву" onClick={() => delEqBreak(i, bi)}>✕</button>
                          {err && <span className="eq-break-err">{err}</span>}
                        </div>
                      );
                    })}
                    <button className="btn btn-ghost btn-sm eq-break-add" type="button" onClick={() => addEqBreak(i)}>＋ Перерва</button>
                  </div>
                </>
                );
              })()}

              {e.perDay && (
                <div className="eq-perday-list">
                  {e.days.some((d) => d) ? (
                    EQ_DAYS.map((d, di) => (e.days[di] ? (
                      <div key={d} className="eq-perday-row">
                        <span className="eq-perday-day">{d}</span>
                        <div className="eq-perday-fields">
                          {(() => { const dhErr = dayHoursError(e.dayHours[di].start, e.dayHours[di].end); return (<>
                          <div className="eq-hours">
                            <input className={"inp tabular eq-time" + (dhErr ? " invalid" : "")} type="time" value={e.dayHours[di].start} onChange={(ev) => setEqDay(i, di, "start", ev.target.value)} />
                            <span className="eq-dash">–</span>
                            <input className={"inp tabular eq-time" + (dhErr ? " invalid" : "")} type="time" value={e.dayHours[di].end} onChange={(ev) => setEqDay(i, di, "end", ev.target.value)} />
                          </div>
                          {dhErr && <span className="eq-break-err">{dhErr}</span>}
                          </>); })()}
                          <div className="eq-breaks">
                            {e.dayHours[di].breaks.map((b, bi) => {
                              const err = breakRowError(e.dayHours[di].breaks, bi, e.dayHours[di].start, e.dayHours[di].end);
                              return (
                                <div className={"eq-break-row" + (err ? " has-err" : "")} key={bi}>
                                  <span className="eq-break-tag">Перерва</span>
                                  <div className="eq-hours">
                                    <input className={"inp tabular eq-time" + (err ? " invalid" : "")} type="time" value={b.start} onChange={(ev) => setEqDayBreak(i, di, bi, "start", ev.target.value)} />
                                    <span className="eq-dash">–</span>
                                    <input className={"inp tabular eq-time" + (err ? " invalid" : "")} type="time" value={b.end} onChange={(ev) => setEqDayBreak(i, di, bi, "end", ev.target.value)} />
                                  </div>
                                  <button className="mini-icon" type="button" title="Прибрати перерву" onClick={() => delEqDayBreak(i, di, bi)}>✕</button>
                                  {err && <span className="eq-break-err">{err}</span>}
                                </div>
                              );
                            })}
                            <button className="btn btn-ghost btn-sm eq-break-add" type="button" onClick={() => addEqDayBreak(i, di)}>＋ Перерва</button>
                          </div>
                        </div>
                      </div>
                    ) : null))
                  ) : (
                    <div className="eq-perday-empty">Оберіть робочі дні вище.</div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        <button className="btn btn-secondary btn-sm add-btn" type="button" onClick={addEq}>＋ Додати обладнання</button>
      </div>

      </>)}

      {active === "sec-price" && (<>
      <h1 className="wiz-h">Послуги та прайс</h1>
      <div className="info-banner" style={{ marginTop: 12 }}>
        <span className="ib-ic" style={{ color: "var(--blue)" }}>₴</span>
        <span className="ib-txt">
          <b>Базовий каталог центру</b> — перелік досліджень, тривалості та ціни на модальність.
          Для <b>кожного кабінета</b> ціну/тривалість/склад можна переозначити окремо — оберіть
          кабінет у списку «Налаштувати». Порожні поля кабінета успадковують базовий каталог.
          {rooms.length === 0 && <> <b style={{ color: "var(--orange)" }}>Спершу додайте й збережіть кабінети</b> (крок «Обладнання та кабінети») — тоді зʼявиться налаштування по кабінетах.</>}
        </span>
      </div>
      <div style={{ marginTop: 14 }}>
        <ServicesEditor clinicId={clinicId} services={services} rooms={rooms} roomOverrides={roomOverrides} embedded />
      </div>
      </>)}

      {delAsk && (() => {
        const blocked = (delAsk.count ?? 0) > 0;   // є активні записи → видаляти не можна
        return (
          <ConfirmDialog
            title={blocked ? "Не можна видалити кабінет" : "Видалити кабінет?"}
            text={
              delAsk.checking
                ? <>Перевіряю записи в кабінеті <b>{delAsk.name}</b>…</>
                : blocked
                  ? <>У кабінеті <b>{delAsk.name}</b> — <b>{delAsk.count}</b> активних запис(ів) у черзі. Спершу перенесіть або скасуйте їх — інакше пацієнти залишаться без кабінету.</>
                  : delAsk.count === null
                    ? <>Не вдалося перевірити записи кабінету <b>{delAsk.name}</b>. Видалити? Якщо в ньому є пацієнти, збереження буде заблоковано.</>
                    : <>Кабінет <b>{delAsk.name}</b> буде видалено з центру при збереженні. Скасувати дію потім не можна.</>
            }
            danger={!blocked}
            busy={delAsk.checking}
            hideCancel={blocked}
            confirmLabel={blocked ? "Зрозуміло" : "Видалити"}
            cancelLabel="Скасувати"
            onClose={() => setDelAsk(null)}
            onConfirm={() => {
              if (delAsk.checking) return;
              if (!blocked) delEq(delAsk.i);
              setDelAsk(null);
            }}
          />
        );
      })()}
    </div>
  );
}

/* ---------- Майстер (контейнер) ---------- */
type SetupRoom = { id: string; modality: string; name: string; apparatus_model?: string | null };
type ServiceRow = Tables<"services">;
type SroRow = Tables<"service_room_overrides">;

export default function SetupWizard({ clinicId, userId, initial, rooms = [], services = [], roomOverrides = [], clinicName, adminName, queuePolicy }: { clinicId: string; userId: string; initial: WizardInitial; rooms?: SetupRoom[]; services?: ServiceRow[]; roomOverrides?: SroRow[]; clinicName?: string; adminName?: string; queuePolicy: QueuePolicyInitial }) {
  const router = useRouter();
  const [activeSection, setActiveSection] = useState("sec-clinic");
  const [saving, setSaving] = useState(false);
  const [valid, setValid] = useState<Record<number, boolean>>({});
  const [dirty, setDirty] = useState(false);
  const [exitAsk, setExitAsk] = useState(false);
  const [toasts, push] = useToasts();
  const dataRef = useRef<WizardData | null>(null);
  const savedRef = useRef<string | null>(null); // знімок збережених даних форми

  function report(k: number, ok: boolean) { setValid((v) => (v[k] === ok ? v : { ...v, [k]: ok })); }
  function onData(d: WizardData) {
    dataRef.current = d;
    const snap = JSON.stringify(d);
    if (savedRef.current === null) { savedRef.current = snap; return; } // базовий знімок при першому завантаженні
    setDirty(snap !== savedRef.current);
  }

  async function save(): Promise<boolean> {
    const d = dataRef.current;
    if (!d || saving) return false;
    setSaving(true);
    const clean = (a: string[]) => a.map((x) => x.trim()).filter(Boolean);
    try {
      const supabase = createClient();

      /* Таймзона — ЯВНИЙ вибір адміна (поле в профілі центру). Раніше сюди щоразу
         писалась зона БРАУЗЕРА оператора: адмін із іншої країни (або з VPN) мовчки
         ламав час усієї клініки — а від нього залежать «Запізнення», «Уточнити»,
         гарди виклику й заборона запису в минуле. Порожню/невалідну зону не пишемо. */
      const tz = (d.timezone || "").trim();
      const tzValid = !!tz && (() => {
        try { new Intl.DateTimeFormat("uk-UA", { timeZone: tz }); return true; } catch { return false; }
      })();
      if (tz && !tzValid) {
        push("Некоректний часовий пояс центру", "error");
        setSaving(false);
        return false;
      }

      const { error: ce } = await supabase
        .from("clinics")
        .update({
          name: d.clinic.trim(),
          city: d.city.trim() || null,
          address: d.address.trim() || null,
          phones: clean(d.phones),
          emails: clean(d.emails),
          ...(tzValid ? { timezone: tz } : {}),
          configured_at: new Date().toISOString(),
        })
        .eq("id", clinicId);
      if (ce) throw ce;

      const { error: pe } = await supabase
        .from("profiles")
        .update({
          full_name: d.adminName.trim() || null,
          phone: (d.aPhones.find((p) => p.trim()) || "").trim() || null,
        })
        .eq("id", userId);
      if (pe) throw pe;

      // Кабінети: оновлюємо наявні за id, додаємо нові, видаляємо лише прибрані.
      const roomFields = (e: EquipItem): TablesInsert<"rooms"> => ({
        clinic_id: clinicId,
        name: (e.room || e.type).trim(),
        modality: modalityCode(e.type),
        apparatus_model: e.desc.trim() || null,
        schedule: {
          days: e.days, start: e.start, end: e.end,
          // Не зберігаємо некоректні інтервали (кінець ≤ початку / незаповнені).
          breaks: e.breaks.filter((b) => b.start && b.end && b.end > b.start),
          perDay: e.perDay,
          dayHours: e.dayHours.map((dh) => ({ start: dh.start, end: dh.end, breaks: dh.breaks.filter((b) => b.start && b.end && b.end > b.start) })),
        } as unknown as Json,
      });
      /* ⚠ Видалення кабінету — НЕ безпечна операція: queue_entries.room_id має
         ON DELETE SET NULL (0001), тож усі записи пацієнтів (зокрема майбутні)
         лишилися б у базі з room_id = NULL: зникають із дошки кабінету, їх не
         можна викликати в кабінет, і ніхто про це не дізнається (раніше тут був
         просто тост «Зміни збережено»). Тому: перевіряємо ДО будь-яких записів
         у БД і блокуємо збереження, поки активні записи не перенесуть/скасують. */
      const { data: existingRooms } = await supabase.from("rooms").select("id, name").eq("clinic_id", clinicId);
      const keptIds = d.equip.map((e) => e.roomId).filter(Boolean) as string[];
      const removedRooms = (existingRooms || []).filter((r) => !keptIds.includes(r.id));
      if (removedRooms.length) {
        const { data: blockers, error: be } = await supabase
          .from("queue_entries")
          .select("room_id")
          .in("room_id", removedRooms.map((r) => r.id))
          /* 0079: needs_reschedule ОБОВʼЯЗКОВО тут. Запис без слота — це все ще
             живий пацієнт, який чекає на дзвінок реєстратури. Без нього кабінет
             видалився б МОВЧКИ, room_id став би NULL (on delete set null) — рівно
             та втрата записів, від якої цей блокер і ставили (P0 UX-аудиту). */
          .in("status", ["scheduled", "waiting", "in_progress", "needs_reschedule"]);
        if (be) throw be;
        if (blockers && blockers.length) {
          const byRoom: Record<string, number> = {};
          blockers.forEach((b) => { const k = String(b.room_id); byRoom[k] = (byRoom[k] || 0) + 1; });
          const list = removedRooms
            .filter((r) => byRoom[r.id])
            .map((r) => `«${r.name}» — ${byRoom[r.id]} запис(ів)`)
            .join("; ");
          push("Не можна видалити кабінет із активними записами: " + list + ". Спершу перенесіть або скасуйте ці записи.", "error");
          setSaving(false);
          return false;
        }
      }

      const keepIds: string[] = [];
      for (const e of d.equip) {
        if (e.roomId) {
          const { error: ue } = await supabase.from("rooms").update(roomFields(e)).eq("id", e.roomId);
          if (ue) throw ue;
          keepIds.push(e.roomId);
        } else {
          const { data: ins, error: ie } = await supabase.from("rooms").insert(roomFields(e)).select("id").single();
          if (ie) throw ie;
          if (ins) keepIds.push(ins.id);
        }
      }
      // Прибрані в майстрі кабінети (активних записів у них уже точно немає — перевірили вище).
      for (const r of removedRooms) {
        const { error: de } = await supabase.from("rooms").delete().eq("id", r.id);
        if (de) throw de;
      }

      savedRef.current = JSON.stringify(d);
      setDirty(false);
      push("Зміни збережено", "success");
      setSaving(false);
      return true;
    } catch (e) {
      push("Помилка збереження: " + ((e as { message?: string })?.message || String(e)), "error");
      setSaving(false);
      return false;
    }
  }

  function exitSetup() {
    if (saving) return;
    if (dirty) { setExitAsk(true); return; }
    router.push("/queue");
  }
  async function saveAndExit() {
    const ok = await save();
    setExitAsk(false);
    if (ok) router.push("/queue");
  }

  return (
    <div className="wiz">
      <aside className="wiz-side">
        <div className="wiz-head">
          <span className="wiz-logo"><span className="dot" />RadFlow</span>
          <div className="wiz-sub">{clinicName || "Налаштування та профіль кабінету"}</div>
        </div>
        <div className="wiz-steps">
          {WIZ_NAV.map((s) => {
            const on = activeSection === s.anchor;
            return (
              <button key={s.label} type="button" className={"wstep" + (on ? " done" : "")} title={s.desc}
                aria-current={on ? "true" : undefined} onClick={() => setActiveSection(s.anchor as string)}
                style={{ width: "100%", textAlign: "left", background: on ? "var(--card-hover)" : "none", border: "none", font: "inherit", cursor: "pointer" }}>
                <span className="wstep-num" aria-hidden />
                <span className="wstep-txt">
                  <span className="wstep-title">{s.label}</span>
                  <span className="wstep-desc">{s.desc}</span>
                </span>
              </button>
            );
          })}
        </div>
        <div className="wiz-foot">
          <div className="wiz-prog-lab">
            <span>Майстер налаштувань</span>
            <a href="mailto:support@radflow.ua?subject=Допомога%20з%20налаштуванням" title="Написати в підтримку">Підтримка</a>
          </div>
        </div>
      </aside>

      <div className="wiz-main">
        <div className="wiz-main-inner">
          {(
            <>
              {/* Кожне вікно налаштувань — окремо; перемикається кружками зліва */}
              <div style={{ display: FORM_SECTIONS.includes(activeSection) ? "block" : "none" }}>
                <StepRegister report={report} onData={onData} initial={initial} active={activeSection}
                  clinicId={clinicId} services={services} rooms={rooms} roomOverrides={roomOverrides} />
              </div>

              {/* 0078 — політика черги при затримці дослідження (лише адмін). */}
              <div className="fade-in" style={{ display: activeSection === "sec-queue" ? "block" : "none" }}>
                <h1 className="wiz-h">Управління чергою</h1>
                <p className="wiz-hsub">Що робити, коли дослідження затягнулося і наїжджає на наступні записи.</p>
                <QueuePolicySettings initial={queuePolicy} />
              </div>

              <div className="fade-in" style={{ display: activeSection === "sec-staff" ? "block" : "none" }}>
                <h1 className="wiz-h">Персонал і доступи</h1>
                <StaffManager embedded clinicId={clinicId} rooms={rooms} clinicName={clinicName} adminName={adminName} />
              </div>

              <div className="fade-in" style={{ display: activeSection === "sec-referrers" ? "block" : "none" }}>
                <h1 className="wiz-h">Лікарі-направники</h1>
                <ReferrersManager embedded clinicId={clinicId} rooms={rooms} clinicName={clinicName} adminName={adminName} />
              </div>

              <div className="fade-in" style={{ display: activeSection === "sec-ceo" ? "block" : "none" }}>
                <h1 className="wiz-h">Керівники (CEO)</h1>
                <CeoManager embedded clinicId={clinicId} clinicName={clinicName} adminName={adminName} />
              </div>
            </>
          )}
        </div>

        <div className="wiz-bar">
          <div className="wiz-bar-inner">
            <div className="wiz-bar-right" style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
              <span className="wiz-cta-wrap" title={valid[1] ? undefined : "Заповніть назву клініки, місто, ПІБ і телефон адміністратора та хоча б один апарат"}>
                <button className="btn btn-green" onClick={save} disabled={!valid[1] || saving}>
                  {saving ? "Зберігаємо…" : "Зберегти"}
                </button>
              </span>
              <button className="btn btn-secondary" onClick={exitSetup} disabled={saving}>Вийти</button>
            </div>
          </div>
        </div>
      </div>

      {exitAsk && (
        <div className="overlay" onClick={() => !saving && setExitAsk(false)}>
          <div className="dialog fade-in" style={{ maxWidth: 420 }} onClick={(e) => e.stopPropagation()}>
            <div className="dlg-head"><div className="dlg-title">Незбережені зміни</div><button className="icon-btn" onClick={() => setExitAsk(false)} disabled={saving}>✕</button></div>
            <div className="dlg-body">У налаштуваннях є незбережені зміни. Зберегти їх перед виходом?</div>
            <div className="dlg-foot" style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
              <button className="btn btn-ghost" onClick={() => setExitAsk(false)} disabled={saving}>Скасувати</button>
              <button className="btn btn-secondary" onClick={() => { setExitAsk(false); router.push("/queue"); }} disabled={saving}>Вийти без збереження</button>
              <button className="btn btn-green" onClick={saveAndExit} disabled={saving}>{saving ? "Зберігаємо…" : "Зберегти й вийти"}</button>
            </div>
          </div>
        </div>
      )}
      <Toasts toasts={toasts} />
    </div>
  );
}
