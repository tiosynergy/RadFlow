"use client";

/* ===== RadFlow — Поломка / Технічне обслуговування =====
   Два окремі події в ОДНОМУ діалозі, кожне редагується незалежно:
     🔧 Поломка обладнання  — як правило блокування «зараз» (status active);
     ⚙️ Планове ТО          — запланований простій у майбутньому (status planned).
   Події одного кабінету не можуть перетинатися в часі (перевірка перетину).
   Якщо подія вже існує — показується з можливістю редагувати / зняти. */

import { useState } from "react";
import { roomScheduleFor, type DayOverride } from "@/lib/schedule";
import { wallNow } from "@/lib/incidents";
import { useModalA11y } from "@/lib/useModalA11y";
import { modalityShort, modalityKind } from "@/lib/studies";

type RoomOpt = { id: string; modality: string; name: string; apparatus_model?: string | null; schedule?: unknown };
type IncidentRow = {
  id: string;
  room_id: string;
  reason: string;
  started_at: string;
  blocked_until?: string | null;
  auto_unblock?: boolean | null;
};
type IncidentSavePayload = {
  id?: string;
  roomId: string;
  reason: string;
  reasonLabel: string;
  startedAt: string;
  blockedUntil: string | null;
  autoUnblock: boolean;
  note: string;
};
type Overrides = Record<string, DayOverride | null>;

function pad(n: number) { return String(n).padStart(2, "0"); }

/* «Зараз» — у НАСТІННОМУ часі КЛІНІКИ, не браузера (аудит 2026-07-12).
   Час інцидентів кодується як настінний UTC (канон 0035), і БД (0065/0066) рахує
   planned/active порівнянням із настінним «зараз» клініки. Якщо дефолт форми брати
   з годинника браузера (getHours()), то в оператора з іншої зони поломка «зараз»
   лягала б як 'planned' → unique-індекс «один активний інцидент» її не покриває,
   кабінет не блокується, пацієнт не йде в «Не відбулося». */
function wallNowDate() { return new Date(wallNow()); }   // wallNow() = мс настінного часу клініки (як UTC)
function nowHHMM() { const d = wallNowDate(); return pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()); }
function todayWall() { const d = wallNowDate(); return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()); }
function dateVal(d: Date) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
function hhmmFromISO(iso: string | null | undefined) { return String(iso || "").slice(11, 16) || nowHHMM(); }
function dtFrom(dateStr: string, hhmm: string) { const [h, m] = String(hhmm).split(":").map(Number); const [Y, Mo, D] = String(dateStr).split("-").map(Number); return new Date(Date.UTC(Y, (Mo || 1) - 1, D || 1, h || 0, m || 0, 0, 0)); }
function isoDate(iso: string | null | undefined) { return String(iso || "").slice(0, 10); }
function nextWorkday(d: Date) { const x = new Date(d); while (x.getDay() === 0) x.setDate(x.getDate() + 1); return x; }
function fmtDT(iso: string | null | undefined) { try { return new Date(iso as string).toLocaleString("uk-UA", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: "UTC" }); } catch { return ""; } }
function overlaps(aS: number, aE: number, bS: number, bE: number) { return aS < bE && bS < aE; }

const DURATIONS = [
  { k: "1h", label: "1 год" }, { k: "2h", label: "2 год" }, { k: "4h", label: "4 год" },
  { k: "eod", label: "До кінця дня" }, { k: "restore", label: "До відновлення" },
];

/* ── 🔧 Поломка обладнання ── */
interface BreakdownSectionProps {
  roomId: string;
  room?: RoomOpt;
  existing?: IncidentRow;
  others?: IncidentRow[];
  onSave: (p: IncidentSavePayload) => void;
  onResolve: (id: string) => void;
  overrides?: Overrides;
}

function BreakdownSection({ roomId, room, existing, others, onSave, onResolve, overrides = {} }: BreakdownSectionProps) {
  const [open, setOpen] = useState(!existing); // немає події → одразу форма; є → спершу зведення
  const [startDate, setStartDate] = useState(existing ? isoDate(existing.started_at) : dateVal(todayWall()));
  const [startTime, setStartTime] = useState(existing ? hhmmFromISO(existing.started_at) : nowHHMM());
  const [durKey, setDurKey] = useState(existing ? "restore" : "");
  const [restoreDate, setRestoreDate] = useState(existing?.blocked_until ? isoDate(existing.blocked_until) : dateVal(nextWorkday((() => { const d = todayWall(); d.setDate(d.getDate() + 1); return d; })())));
  const [restoreTime, setRestoreTime] = useState(existing?.blocked_until ? hhmmFromISO(existing.blocked_until) : "08:00");
  const [autoUnblock, setAutoUnblock] = useState(existing ? existing.auto_unblock !== false : true);
  const [err, setErr] = useState("");

  // Кінець дня — за ефективним графіком кабінету на дату початку (з урахуванням особливого графіка/overrides).
  const schedEnd = (() => {
    const d = dtFrom(startDate, "00:00");
    return roomScheduleFor(d, roomId, overrides[startDate] || null, room?.schedule).end;
  })();
  function blockedUntil(startedAt: Date): Date | null {
    if (durKey === "1h") return new Date(startedAt.getTime() + 3600e3);
    if (durKey === "2h") return new Date(startedAt.getTime() + 2 * 3600e3);
    if (durKey === "4h") return new Date(startedAt.getTime() + 4 * 3600e3);
    if (durKey === "eod") { return dtFrom(startDate, schedEnd); }
    if (durKey === "restore") return dtFrom(restoreDate, restoreTime);
    return null;
  }
  function save() {
    setErr("");
    if (!durKey) { setErr("Оберіть тривалість"); return; }
    const s = dtFrom(startDate, startTime), e = blockedUntil(s);
    if (e && e.getTime() <= s.getTime()) { setErr("Кінець має бути пізніше початку"); return; }
    const eMs = e ? e.getTime() : Infinity;
    if ((others || []).some((o) => overlaps(s.getTime(), eMs, new Date(o.started_at).getTime(), o.blocked_until ? new Date(o.blocked_until).getTime() : Infinity))) {
      setErr("Період перетинається з ТО цього кабінету"); return;
    }
    const durLabel = durKey === "restore" ? "до " + restoreDate + " " + restoreTime : DURATIONS.find((d) => d.k === durKey)?.label;
    onSave({ id: existing?.id, roomId, reason: "breakdown", reasonLabel: "Поломка обладнання", startedAt: s.toISOString(), blockedUntil: e ? e.toISOString() : null, autoUnblock, note: "Поломка " + startDate + " " + startTime + " · " + durLabel });
    setOpen(false);
  }

  return (
    <div style={{ border: "1px solid var(--red)", borderRadius: 12, padding: 14, background: "var(--red-bg)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 16 }}>🔧</span>
        <b style={{ color: "var(--red)" }}>Поломка обладнання</b>
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>несправність — потрібен ремонт</span>
      </div>
      {existing && !open ? (
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          <span style={{ flex: 1, fontSize: 13 }}>Активна з <b>{fmtDT(existing.started_at)}</b>{existing.blocked_until ? <> до <b>{fmtDT(existing.blocked_until)}</b></> : null}</span>
          <button className="btn btn-secondary btn-sm" onClick={() => setOpen(true)}>✎ Редагувати</button>
          <button className="btn btn-secondary btn-sm" onClick={() => onResolve(existing.id)}>🔓 Розблокувати</button>
        </div>
      ) : (
        <>
          <div className="fld-row">
            <label className="fld" style={{ maxWidth: 160 }}><span className="fld-lab">Дата початку <span className="req">*</span></span><input className="inp tabular" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} /></label>
            <label className="fld" style={{ maxWidth: 110 }}><span className="fld-lab">Час <span className="req">*</span></span><input className="inp tabular" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} /></label>
          </div>
          <div className="fld"><span className="fld-lab">Тривалість <span className="req">*</span></span>
            <div className="bd-durs">{DURATIONS.map((d) => <button key={d.k} className={"bd-chip" + (durKey === d.k ? " active" : "")} onClick={() => setDurKey(d.k)}>{d.label}</button>)}</div>
          </div>
          {durKey === "restore" && (
            <div className="fld-row">
              <label className="fld" style={{ maxWidth: 160 }}><span className="fld-lab">Дата відновлення <span className="req">*</span></span><input className="inp tabular" type="date" min={startDate} value={restoreDate} onChange={(e) => setRestoreDate(e.target.value)} /></label>
              <label className="fld" style={{ maxWidth: 110 }}><span className="fld-lab">Час <span className="req">*</span></span><input className="inp tabular" type="time" value={restoreTime} onChange={(e) => setRestoreTime(e.target.value)} /></label>
            </div>
          )}
          <label className={"rf-check" + (autoUnblock ? " on" : "")} style={{ marginTop: 4 }}>
            <input type="checkbox" checked={autoUnblock} onChange={(e) => setAutoUnblock(e.target.checked)} />
            <span className="rf-box" /><span>Автоматично зняти блокування у вказаний час {autoUnblock ? "" : "— інакше підтвердьте зняття вручну"}</span>
          </label>
          {err && <div className="ctx-hint red" style={{ fontSize: 12.5 }}>⚠ {err}</div>}
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 8 }}>
            {existing && <button className="btn btn-ghost btn-sm" onClick={() => setOpen(false)}>Скасувати</button>}
            <button className="btn btn-danger btn-sm" onClick={save}>{existing ? "💾 Зберегти" : "🔒 Заблокувати"}</button>
          </div>
        </>
      )}
    </div>
  );
}

/* ── ⚙️ Планове ТО ── */
interface MaintenanceSectionProps {
  roomId: string;
  existing?: IncidentRow;
  others?: IncidentRow[];
  onSave: (p: IncidentSavePayload) => void;
  onResolve: (id: string) => void;
}

function MaintenanceSection({ roomId, existing, others, onSave, onResolve }: MaintenanceSectionProps) {
  const tmrw = dateVal(nextWorkday((() => { const d = todayWall(); d.setDate(d.getDate() + 1); return d; })()));
  const [open, setOpen] = useState(!existing);
  const [startDate, setStartDate] = useState(existing ? isoDate(existing.started_at) : tmrw);
  const [startTime, setStartTime] = useState(existing ? hhmmFromISO(existing.started_at) : "08:00");
  const [endDate, setEndDate] = useState(existing?.blocked_until ? isoDate(existing.blocked_until) : tmrw);
  const [endTime, setEndTime] = useState(existing?.blocked_until ? hhmmFromISO(existing.blocked_until) : "12:00");
  const [autoUnblock, setAutoUnblock] = useState(existing ? existing.auto_unblock !== false : true);
  const [err, setErr] = useState("");

  function save() {
    setErr("");
    const s = dtFrom(startDate, startTime), e = dtFrom(endDate, endTime);
    if (e.getTime() <= s.getTime()) { setErr("Кінець має бути пізніше початку"); return; }
    if ((others || []).some((o) => overlaps(s.getTime(), e.getTime(), new Date(o.started_at).getTime(), o.blocked_until ? new Date(o.blocked_until).getTime() : Infinity))) {
      setErr("Період перетинається з поломкою цього кабінету"); return;
    }
    onSave({ id: existing?.id, roomId, reason: "maintenance", reasonLabel: "Планове ТО", startedAt: s.toISOString(), blockedUntil: e.toISOString(), autoUnblock, note: "Планове ТО " + startDate + " " + startTime + "–" + endDate + " " + endTime });
    setOpen(false);
  }

  return (
    <div style={{ border: "1px solid var(--orange)", borderRadius: 12, padding: 14, background: "var(--orange-bg)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 16 }}>⚙️</span>
        <b style={{ color: "var(--orange)" }}>Планове ТО</b>
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>заплановане технічне обслуговування</span>
      </div>
      {existing && !open ? (
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          <span style={{ flex: 1, fontSize: 13 }}>Заплановано <b>{fmtDT(existing.started_at)}</b>{existing.blocked_until ? <> – <b>{fmtDT(existing.blocked_until)}</b></> : null}</span>
          <button className="btn btn-secondary btn-sm" onClick={() => setOpen(true)}>✎ Редагувати</button>
          <button className="btn btn-secondary btn-sm" onClick={() => onResolve(existing.id)}>✕ Скасувати</button>
        </div>
      ) : (
        <>
          <div className="fld-row">
            <label className="fld" style={{ maxWidth: 160 }}><span className="fld-lab">Початок — дата <span className="req">*</span></span><input className="inp tabular" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} /></label>
            <label className="fld" style={{ maxWidth: 110 }}><span className="fld-lab">Час <span className="req">*</span></span><input className="inp tabular" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} /></label>
          </div>
          <div className="fld-row">
            <label className="fld" style={{ maxWidth: 160 }}><span className="fld-lab">Кінець — дата <span className="req">*</span></span><input className="inp tabular" type="date" min={startDate} value={endDate} onChange={(e) => setEndDate(e.target.value)} /></label>
            <label className="fld" style={{ maxWidth: 110 }}><span className="fld-lab">Час <span className="req">*</span></span><input className="inp tabular" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} /></label>
          </div>
          <label className={"rf-check" + (autoUnblock ? " on" : "")} style={{ marginTop: 4 }}>
            <input type="checkbox" checked={autoUnblock} onChange={(e) => setAutoUnblock(e.target.checked)} />
            <span className="rf-box" /><span>Автоматично зняти ТО наприкінці {autoUnblock ? "" : "— інакше підтвердьте зняття вручну"}</span>
          </label>
          {err && <div className="ctx-hint red" style={{ fontSize: 12.5 }}>⚠ {err}</div>}
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 8 }}>
            {existing && <button className="btn btn-ghost btn-sm" onClick={() => setOpen(false)}>Скасувати</button>}
            <button className="btn btn-primary btn-sm" onClick={save}>{existing ? "💾 Зберегти" : "🗓 Запланувати ТО"}</button>
          </div>
        </>
      )}
    </div>
  );
}

interface BreakdownModalProps {
  rooms?: RoomOpt[];
  incidents?: IncidentRow[];
  overrides?: Overrides;
  initialRoomId?: string;
  onClose: () => void;
  onSubmit: (p: IncidentSavePayload) => void;
  onResolve: (id: string) => void;
}

export default function BreakdownModal({ rooms, incidents = [], overrides = {}, initialRoomId, onClose, onSubmit, onResolve }: BreakdownModalProps) {
  const dialogRef = useModalA11y<HTMLDivElement>(onClose);
  const [roomId, setRoomId] = useState(initialRoomId || (rooms || [])[0]?.id || "");
  const room = (rooms || []).find((r) => r.id === roomId);
  const roomIncidents = (incidents || []).filter((i) => i.room_id === roomId);
  const breakdownInc = roomIncidents.find((i) => i.reason === "breakdown");
  const maintenanceInc = roomIncidents.find((i) => i.reason === "maintenance");
  const emergencyInc = roomIncidents.find((i) => i.reason === "emergency");

  return (
    <div className="overlay">
      <div className="dialog fade-in" style={{ maxWidth: 600 }} ref={dialogRef} role="dialog" aria-modal="true" aria-label="Поломка або технічне обслуговування">
        <div className="dlg-head">
          <div className="dlg-title"><span className="tic" style={{ background: "var(--red-bg)", color: "var(--red)" }}>🔧</span>Поломка / Технічне обслуговування</div>
          <button className="icon-btn" onClick={onClose}>✕</button>
        </div>
        <div className="dlg-body" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="fld" style={{ marginBottom: 0 }}>
            <span className="fld-lab">Який апарат? <span className="req">*</span></span>
            <div className="bd-rooms">
              {(rooms || []).map((r) => (
                <button key={r.id} className={"bd-room" + (roomId === r.id ? " active" : "")} onClick={() => setRoomId(r.id)} title={r.name + (r.apparatus_model ? " · " + r.apparatus_model : "")}>
                  <span className={"bd-room-kind " + modalityKind(r.modality)}>{modalityShort(r.modality)}</span>
                  <span className="bd-room-meta"><span className="bd-room-name">{r.name}</span><span className="bd-room-model">{r.apparatus_model || ""}</span></span>
                </button>
              ))}
            </div>
          </div>

          {emergencyInc && (
            <div style={{ border: "1px solid var(--red)", borderRadius: 12, padding: 14, background: "var(--red-bg)", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              <span style={{ fontSize: 16 }}>🛑</span>
              <b style={{ color: "var(--red)" }}>Аварійна зупинка</b>
              <span style={{ flex: 1, fontSize: 13 }}>Активна з <b>{fmtDT(emergencyInc.started_at)}</b> — до зʼясування обставин</span>
              <button className="btn btn-secondary btn-sm" onClick={() => onResolve(emergencyInc.id)}>🔓 Розблокувати</button>
            </div>
          )}

          <BreakdownSection key={"b-" + roomId + "-" + (breakdownInc?.id || "new")} roomId={roomId} room={room} existing={breakdownInc} others={maintenanceInc ? [maintenanceInc] : []} onSave={onSubmit} onResolve={onResolve} overrides={overrides} />
          <MaintenanceSection key={"m-" + roomId + "-" + (maintenanceInc?.id || "new")} roomId={roomId} existing={maintenanceInc} others={breakdownInc ? [breakdownInc] : []} onSave={onSubmit} onResolve={onResolve} />

          <div className="hint-blue" style={{ marginBottom: 0 }}>⚡ <b>Realtime:</b> зміни миттєво зʼявляться у всіх ролей. Поломка блокує апарат відразу; планове ТО — у вказаний час.</div>
        </div>
        <div className="dlg-foot">
          <button className="btn btn-ghost" onClick={onClose} style={{ marginLeft: "auto" }}>Закрити</button>
        </div>
      </div>
    </div>
  );
}
