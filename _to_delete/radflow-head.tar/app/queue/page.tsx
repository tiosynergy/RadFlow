import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import QueueBoard from "@/components/QueueBoard";

export default async function QueuePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("clinic_id, full_name, role, clinics(name, configured_at, timezone)")
    .eq("id", user.id)
    .single();
  if (!profile) redirect("/login");
  if (profile.role === "radiologist") redirect("/radiologist");
  if (profile.role === "referrer") redirect("/referral");
  if (profile.role === "ceo") redirect("/ceo"); // керівник — на свій дашборд

  const clinic = (Array.isArray(profile.clinics) ? profile.clinics[0] : profile.clinics) as
    | { name?: string; configured_at: string | null; timezone?: string | null }
    | null
    | undefined;
  if (clinic && !clinic.configured_at) redirect("/setup");

  const ROLE_LABELS: Record<string, string> = {
    admin: "Адміністратор", radiologist: "Радіолог", registrar: "Реєстратор", referrer: "Лікар-направник", ceo: "Керівник",
  };

  const { data: rooms } = await supabase
    .from("rooms")
    .select("id, name, modality, apparatus_model, schedule")
    .eq("clinic_id", profile.clinic_id as string)
    .order("name");

  // Каталог послуг центру (services, 0107) — SSR-проп у форми запису (фаза 2a).
  // ВСІ рядки (у т.ч. active=false): buildCatalog сам відсіює неактивні, але за
  // наявністю рядка розрізняє «модальність не налаштовували» (→ статика) від «усі
  // позиції вимкнені» (→ порожньо, напрям закрито). Фільтр active тут знову відкривав
  // би статику при вимкненні всіх послуг модальності (High-2).
  const { data: services } = await supabase
    .from("services")
    .select("id, name, modality, duration_min, price, contrast_allowed, contrast_price, active, sort_order")
    .eq("clinic_id", profile.clinic_id as string)
    .order("sort_order");

  // Переозначення каталогу по кабінетах (service_room_overrides, 0108) — SSR-проп у
  // форми запису (фаза 2b): при обраному кабінеті ціна/тривалість беруться per-room.
  // Беремо ВСІ рядки центру (у т.ч. active=false — вони ховають позицію в кабінеті).
  const { data: roomOverrides } = await supabase
    .from("service_room_overrides")
    .select("room_id, service_id, price, duration_min, contrast_price, active")
    .eq("clinic_id", profile.clinic_id as string);

  return (
    <QueueBoard
      clinicId={profile.clinic_id as string}
      // Зона центру — із сервера: клієнтський fetch прилітав ПІСЛЯ монтування, і
      // початкова дата дошки встигала зафіксуватися по браузеру (M-4).
      clinicTz={clinic?.timezone || "UTC"}
      rooms={rooms ?? []}
      services={services ?? []}
      roomOverrides={roomOverrides ?? []}
      clinicName={clinic?.name ?? ""}
      adminName={(profile.full_name as string) ?? (user.email ?? "")}
      adminRole={profile.role ? ROLE_LABELS[profile.role as string] ?? (profile.role as string) : "Адміністратор"}
      roleKey={(profile.role as string) ?? "admin"}
    />
  );
}
